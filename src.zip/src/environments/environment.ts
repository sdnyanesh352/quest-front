export const environment = {
  production:false,
  firebaseConfig:{

    apiKey: "AIzaSyABdmKDUX8h0dFApOwBMoViT2mfnnrtD_w",
    authDomain: "questdata-e1c18.firebaseapp.com",
    databaseURL: "https://questdata-e1c18-default-rtdb.firebaseio.com",
    projectId: "questdata-e1c18",
    storageBucket: "questdata-e1c18.appspot.com",
    messagingSenderId: "331074898645",
    appId: "1:331074898645:web:5101cf85d5580579ff705c",
    measurementId: "G-3DM3D9TRYQ"
  },
};