export class EmployeeForm

{
    projectName!:string;
    email!:string;
}