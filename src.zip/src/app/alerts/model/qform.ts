export class Qform

{
    id!: number;
    question!:string;
    answer!:string;
    company!:string;
}